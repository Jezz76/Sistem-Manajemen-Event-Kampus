
<h2>Tambah Event</h2>
<form method="post">
  <div class="mb-3">
    <label>Nama</label>
    <input type="text" name="nama" class="form-control" required>
  </div>
  <div class="mb-3">
    <label>Tempat</label>
    <input type="text" name="tempat" class="form-control" required>
  </div>
  <div class="mb-3">
    <label>Waktu</label>
    <input type="datetime-local" name="waktu" class="form-control" required>
  </div>
  <button type="submit" class="btn btn-success">Simpan</button>
</form>
