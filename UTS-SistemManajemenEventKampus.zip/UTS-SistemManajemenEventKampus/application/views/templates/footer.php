</main>
<footer class="bg-light text-center text-lg-start border-top py-3 mt-auto">
  <div class="text-center">
    © 2025 Sistem Manajemen Event Kampus
  </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
